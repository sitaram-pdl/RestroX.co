(this["webpackJsonprestrox-reception"] = this["webpackJsonprestrox-reception"] || []).push([[5],{

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/Components/Profile/Profile.module.css":
/*!******************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--5-oneOf-5-1!./node_modules/postcss-loader/src??postcss!./src/Components/Profile/Profile.module.css ***!
  \******************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(true);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".Profile_container__37VWw{\n    position: fixed;\n    right: 1.5em;\n    top: 0;\n    display: flex;\n    flex-direction: column;\n    width: max-content;\n    z-index: 2500;\n    align-items: center;\n}\n.Profile_profile__2SlMH{\n    display: flex;\n    flex-direction: row;\n    margin-top: 2vh;\n   justify-content: flex-end;\n   align-items: flex-start;\n  \n}\n.Profile_icons__2Kduq{\n    margin-left: 12px;\n   \n}\n.Profile_text__3fL86{\n    font-family: 'Poppins';\n    color: aliceblue;\n    margin-left: 12px;\n    font-size: 0.7em;\n}\n.Profile_image__33XxL{\n    width: 2em;\n    height: 2em;\n    border-radius: 10px;\n\n    margin-left: 12px;\n}\n.Profile_moon__20NDx{\n    width: 1.5em;\n    height: 1.5em;\n    border-radius: 10px;\n\n    margin-left: 12px;\n}\n.Profile_message__3RLCu{\n    margin-top: 1em;\n    margin-left: 2em;\n    display: flex;\n    align-items: center;\n    width: 25vw;\n   \n}\n.Profile_white__O2dxj{\n    color: black;\n}\n.Profile_dropdown__UOvi8{\n   display: flex;\n   flex-direction: column;\n   width: max(25vw,100%);\n   background-color: #16181A;\n   border-radius: 10px;\n   margin-top: 1em;\n   \n}\n.Profile_title__3rrrm{\n    font-size: 1.5em;\n    margin: 1.2em 1em;\n    display: flex;\n    width: calc(100% - 2em);\n    justify-content: space-between;\n    color: aliceblue;\n}\n.Profile_msgImg__2WLZO{\n    width: 4em;\n    border-radius: 50%;\n    border:4px solid gray;\n    padding: 1px;\n}\n.Profile_name__uA5bx{\n    margin-left: 0.8em;\n    color: aliceblue;\n    font-weight: 600;\n    font-size: 1.1em;\n    margin-left: 1.5em;\n    width: 66%;\n    \n}\n.Profile_sub__12g-4{\n    font-size: 0.7em;\n    font-weight: 400;\n    margin-top: 0.4em;\n    color: gray;\n}\n\n.Profile_messageDrop__3rV_7{\n    height: 80vh;\n    overflow: scroll;\n}\n.Profile_messageDrop__3rV_7::-webkit-scrollbar{\n    height: 0;\n}\n.Profile_seeMore__3MDC7{\n    width: calc(100% - 2em);\n    text-align: center;\n    padding: 1em;\n    color: aliceblue;\n    border-top: 1px solid rgba(240, 248, 255, 0.144);\n}\n\n.Profile_image2__1rgB6{\n    width: 100%;\n    max-width: 200px;\n    display: flex;\n    margin: 2.5em 0;\n    justify-content: center;\n}\n\n.Profile_lower__3riDu{\n    background-color: #202326;\n    width: 98%;\n    display: flex;\n    flex-direction: column;\n    align-items: center;\n    border-radius: 0 0 10px 10px;\n}\n.Profile_image3__gf1Dq{\n    width: 4em;\n    margin-top: -2em;\n    border-radius: 10px;\n}\n.Profile_dropdown2__1cK8a{\n    display: flex;\n    flex-direction: column;\n    align-items: center;\n    width: calc(96% );\n    background-color: #16181A;\n    border-radius: 10px;\n    color: aliceblue;\n }\n .Profile_email__1nueq{\n     font-size: 0.7em;\n }\n\n .Profile_button__1DqQu{\n     border:1px solid tomato;\n     border-radius: 10px;\n     padding: 0.5em 1.5em;\n }\n\n .Profile_column__34t9Q{\n     margin: 1em 0;\n     width: 70%;\n     justify-content: space-around;\n    font-size: 0.7em;\n     display: flex;\n     color: tomato;\n }\n\n .Profile_row__3fBSC{\n     display: flex;\n     flex-direction: column;\n     width: 70%;\n     margin-top: 1em;\n }\n\n .Profile_confirm__2ko_I{\n     font-size: 0.8em;\n }\n\n .Profile_column2__3S100{\n    margin: 1em 0;\n    width: 100%;\n    justify-content: space-around;\n   font-size: 0.9em;\n    display: flex;\n    color: tomato;\n}\n\n.Profile_confirm2__7yWXz{\n    font-size: 0.5em;\n}\n\n.Profile_person__2ORoK{\n    font-size: 1.2em;\n}\n\n.Profile_searchDiv__2hRbr{\n    border: 1px solid rgba(240, 248, 255, 0.101);\n    border-radius: 10px;\n    display: flex;\n    align-items: center;    \n}\n\n\n.Profile_input__2j_bw{\n    border: none;\n    background-color: transparent;\n    padding: 0.5em 1em;\n}\n.Profile_searchDiv2__3vSUx{\n    border-radius: 10px;\n    display: flex;\n    align-items: center;    \n    margin: 0 2em;\n    width: 90%;\n}\n\n\n.Profile_input2__2PfKz{\n    border: none;\n    background-color: transparent;\n    padding: 0.5em 1em;\n}\n\n.Profile_titleOption__1ermh{\n    display: flex;\n    font-size: 1.5em;\n    justify-content: center;   \n    color: aliceblue;\n    margin: 1.5em 0 0.5em 0 ;\n}\n\n.Profile_titleButton__2pI9S{\n    margin: 0 0.5em;\n    padding: 0.5em 2em;\n    background-color: #3081ED;\n    border-radius: 30px;\n    font-weight: 600;\n}\n\n.Profile_btnBlur__1Frg6{\n    padding: 0.5em 1em;\n    color: gray;\n    border-radius: 30px;\n    font-weight: 600;\n}\n\n.Profile_dateTitle__2EiOM{\n    color: white;\n    margin: 1em 2em;\n}\n\n.Profile_subEmail__3JdnV{\n    color: gray;\n    font-weight: 300;\n    font-size: 0.8em;\n}\n\n.Profile_postImage__1Ii8l{\n    margin: 1em 2em;\n    width: 25vw;\n    height: 10vw;\n}\n.Profile_postImg__3DHWu{\n    width: 100%;\n    height: 100%;\n    object-fit: cover;\n    border-radius: 20px;\n}\n\n.Profile_postTitle__1seDG{\n    margin-left: 2em;\n    color: white;\n    font-size: 1.4em;\n}\n\n.Profile_postDesc__1ns0M{\n    margin:0.5em 0 0.5em 3em;\n    width: 20vw;\n    color: gray;\n}\n\n.Profile_insights__13urD{\n    align-items: center;\n    display: flex;\n    font-size: 1.3em;\n    margin-left: 2em;\n    margin-top: 1em;\n}\n\n.Profile_insightsInside__fVGJ3{\ncolor: gray;\nalign-items: center;\ndisplay: flex;\npadding: 0 1em 0 0;\n\n}\n\n.Profile_likeIcon__3AFwu{\n    padding: 0 0.3em;\n    \n}\n\n.Profile_insightsInside3__1rAzX{\n    color: gray;\n    align-items: center;\n    display: flex;\n    margin-left:auto;\n    margin-right: 1.5em;\n    color: #4D77FF;\n    }\n\n    .Profile_addButton__28HgN{\n        margin-right: 1em;\n        color: gray;\n    }\n\n.Profile_timeDiv__1YnQl{\n    color: gray;\n}", "",{"version":3,"sources":["webpack://src/Components/Profile/Profile.module.css"],"names":[],"mappings":"AAAA;IACI,eAAe;IACf,YAAY;IACZ,MAAM;IACN,aAAa;IACb,sBAAsB;IACtB,kBAAkB;IAClB,aAAa;IACb,mBAAmB;AACvB;AACA;IACI,aAAa;IACb,mBAAmB;IACnB,eAAe;GAChB,yBAAyB;GACzB,uBAAuB;;AAE1B;AACA;IACI,iBAAiB;;AAErB;AACA;IACI,sBAAsB;IACtB,gBAAgB;IAChB,iBAAiB;IACjB,gBAAgB;AACpB;AACA;IACI,UAAU;IACV,WAAW;IACX,mBAAmB;;IAEnB,iBAAiB;AACrB;AACA;IACI,YAAY;IACZ,aAAa;IACb,mBAAmB;;IAEnB,iBAAiB;AACrB;AACA;IACI,eAAe;IACf,gBAAgB;IAChB,aAAa;IACb,mBAAmB;IACnB,WAAW;;AAEf;AACA;IACI,YAAY;AAChB;AACA;GACG,aAAa;GACb,sBAAsB;GACtB,qBAAqB;GACrB,yBAAyB;GACzB,mBAAmB;GACnB,eAAe;;AAElB;AACA;IACI,gBAAgB;IAChB,iBAAiB;IACjB,aAAa;IACb,uBAAuB;IACvB,8BAA8B;IAC9B,gBAAgB;AACpB;AACA;IACI,UAAU;IACV,kBAAkB;IAClB,qBAAqB;IACrB,YAAY;AAChB;AACA;IACI,kBAAkB;IAClB,gBAAgB;IAChB,gBAAgB;IAChB,gBAAgB;IAChB,kBAAkB;IAClB,UAAU;;AAEd;AACA;IACI,gBAAgB;IAChB,gBAAgB;IAChB,iBAAiB;IACjB,WAAW;AACf;;AAEA;IACI,YAAY;IACZ,gBAAgB;AACpB;AACA;IACI,SAAS;AACb;AACA;IACI,uBAAuB;IACvB,kBAAkB;IAClB,YAAY;IACZ,gBAAgB;IAChB,gDAAgD;AACpD;;AAEA;IACI,WAAW;IACX,gBAAgB;IAChB,aAAa;IACb,eAAe;IACf,uBAAuB;AAC3B;;AAEA;IACI,yBAAyB;IACzB,UAAU;IACV,aAAa;IACb,sBAAsB;IACtB,mBAAmB;IACnB,4BAA4B;AAChC;AACA;IACI,UAAU;IACV,gBAAgB;IAChB,mBAAmB;AACvB;AACA;IACI,aAAa;IACb,sBAAsB;IACtB,mBAAmB;IACnB,iBAAiB;IACjB,yBAAyB;IACzB,mBAAmB;IACnB,gBAAgB;CACnB;CACA;KACI,gBAAgB;CACpB;;CAEA;KACI,uBAAuB;KACvB,mBAAmB;KACnB,oBAAoB;CACxB;;CAEA;KACI,aAAa;KACb,UAAU;KACV,6BAA6B;IAC9B,gBAAgB;KACf,aAAa;KACb,aAAa;CACjB;;CAEA;KACI,aAAa;KACb,sBAAsB;KACtB,UAAU;KACV,eAAe;CACnB;;CAEA;KACI,gBAAgB;CACpB;;CAEA;IACG,aAAa;IACb,WAAW;IACX,6BAA6B;GAC9B,gBAAgB;IACf,aAAa;IACb,aAAa;AACjB;;AAEA;IACI,gBAAgB;AACpB;;AAEA;IACI,gBAAgB;AACpB;;AAEA;IACI,4CAA4C;IAC5C,mBAAmB;IACnB,aAAa;IACb,mBAAmB;AACvB;;;AAGA;IACI,YAAY;IACZ,6BAA6B;IAC7B,kBAAkB;AACtB;AACA;IACI,mBAAmB;IACnB,aAAa;IACb,mBAAmB;IACnB,aAAa;IACb,UAAU;AACd;;;AAGA;IACI,YAAY;IACZ,6BAA6B;IAC7B,kBAAkB;AACtB;;AAEA;IACI,aAAa;IACb,gBAAgB;IAChB,uBAAuB;IACvB,gBAAgB;IAChB,wBAAwB;AAC5B;;AAEA;IACI,eAAe;IACf,kBAAkB;IAClB,yBAAyB;IACzB,mBAAmB;IACnB,gBAAgB;AACpB;;AAEA;IACI,kBAAkB;IAClB,WAAW;IACX,mBAAmB;IACnB,gBAAgB;AACpB;;AAEA;IACI,YAAY;IACZ,eAAe;AACnB;;AAEA;IACI,WAAW;IACX,gBAAgB;IAChB,gBAAgB;AACpB;;AAEA;IACI,eAAe;IACf,WAAW;IACX,YAAY;AAChB;AACA;IACI,WAAW;IACX,YAAY;IACZ,iBAAiB;IACjB,mBAAmB;AACvB;;AAEA;IACI,gBAAgB;IAChB,YAAY;IACZ,gBAAgB;AACpB;;AAEA;IACI,wBAAwB;IACxB,WAAW;IACX,WAAW;AACf;;AAEA;IACI,mBAAmB;IACnB,aAAa;IACb,gBAAgB;IAChB,gBAAgB;IAChB,eAAe;AACnB;;AAEA;AACA,WAAW;AACX,mBAAmB;AACnB,aAAa;AACb,kBAAkB;;AAElB;;AAEA;IACI,gBAAgB;;AAEpB;;AAEA;IACI,WAAW;IACX,mBAAmB;IACnB,aAAa;IACb,gBAAgB;IAChB,mBAAmB;IACnB,cAAc;IACd;;IAEA;QACI,iBAAiB;QACjB,WAAW;IACf;;AAEJ;IACI,WAAW;AACf","sourcesContent":[".container{\n    position: fixed;\n    right: 1.5em;\n    top: 0;\n    display: flex;\n    flex-direction: column;\n    width: max-content;\n    z-index: 2500;\n    align-items: center;\n}\n.profile{\n    display: flex;\n    flex-direction: row;\n    margin-top: 2vh;\n   justify-content: flex-end;\n   align-items: flex-start;\n  \n}\n.icons{\n    margin-left: 12px;\n   \n}\n.text{\n    font-family: 'Poppins';\n    color: aliceblue;\n    margin-left: 12px;\n    font-size: 0.7em;\n}\n.image{\n    width: 2em;\n    height: 2em;\n    border-radius: 10px;\n\n    margin-left: 12px;\n}\n.moon{\n    width: 1.5em;\n    height: 1.5em;\n    border-radius: 10px;\n\n    margin-left: 12px;\n}\n.message{\n    margin-top: 1em;\n    margin-left: 2em;\n    display: flex;\n    align-items: center;\n    width: 25vw;\n   \n}\n.white{\n    color: black;\n}\n.dropdown{\n   display: flex;\n   flex-direction: column;\n   width: max(25vw,100%);\n   background-color: #16181A;\n   border-radius: 10px;\n   margin-top: 1em;\n   \n}\n.title{\n    font-size: 1.5em;\n    margin: 1.2em 1em;\n    display: flex;\n    width: calc(100% - 2em);\n    justify-content: space-between;\n    color: aliceblue;\n}\n.msgImg{\n    width: 4em;\n    border-radius: 50%;\n    border:4px solid gray;\n    padding: 1px;\n}\n.name{\n    margin-left: 0.8em;\n    color: aliceblue;\n    font-weight: 600;\n    font-size: 1.1em;\n    margin-left: 1.5em;\n    width: 66%;\n    \n}\n.sub{\n    font-size: 0.7em;\n    font-weight: 400;\n    margin-top: 0.4em;\n    color: gray;\n}\n\n.messageDrop{\n    height: 80vh;\n    overflow: scroll;\n}\n.messageDrop::-webkit-scrollbar{\n    height: 0;\n}\n.seeMore{\n    width: calc(100% - 2em);\n    text-align: center;\n    padding: 1em;\n    color: aliceblue;\n    border-top: 1px solid rgba(240, 248, 255, 0.144);\n}\n\n.image2{\n    width: 100%;\n    max-width: 200px;\n    display: flex;\n    margin: 2.5em 0;\n    justify-content: center;\n}\n\n.lower{\n    background-color: #202326;\n    width: 98%;\n    display: flex;\n    flex-direction: column;\n    align-items: center;\n    border-radius: 0 0 10px 10px;\n}\n.image3{\n    width: 4em;\n    margin-top: -2em;\n    border-radius: 10px;\n}\n.dropdown2{\n    display: flex;\n    flex-direction: column;\n    align-items: center;\n    width: calc(96% );\n    background-color: #16181A;\n    border-radius: 10px;\n    color: aliceblue;\n }\n .email{\n     font-size: 0.7em;\n }\n\n .button{\n     border:1px solid tomato;\n     border-radius: 10px;\n     padding: 0.5em 1.5em;\n }\n\n .column{\n     margin: 1em 0;\n     width: 70%;\n     justify-content: space-around;\n    font-size: 0.7em;\n     display: flex;\n     color: tomato;\n }\n\n .row{\n     display: flex;\n     flex-direction: column;\n     width: 70%;\n     margin-top: 1em;\n }\n\n .confirm{\n     font-size: 0.8em;\n }\n\n .column2{\n    margin: 1em 0;\n    width: 100%;\n    justify-content: space-around;\n   font-size: 0.9em;\n    display: flex;\n    color: tomato;\n}\n\n.confirm2{\n    font-size: 0.5em;\n}\n\n.person{\n    font-size: 1.2em;\n}\n\n.searchDiv{\n    border: 1px solid rgba(240, 248, 255, 0.101);\n    border-radius: 10px;\n    display: flex;\n    align-items: center;    \n}\n\n\n.input{\n    border: none;\n    background-color: transparent;\n    padding: 0.5em 1em;\n}\n.searchDiv2{\n    border-radius: 10px;\n    display: flex;\n    align-items: center;    \n    margin: 0 2em;\n    width: 90%;\n}\n\n\n.input2{\n    border: none;\n    background-color: transparent;\n    padding: 0.5em 1em;\n}\n\n.titleOption{\n    display: flex;\n    font-size: 1.5em;\n    justify-content: center;   \n    color: aliceblue;\n    margin: 1.5em 0 0.5em 0 ;\n}\n\n.titleButton{\n    margin: 0 0.5em;\n    padding: 0.5em 2em;\n    background-color: #3081ED;\n    border-radius: 30px;\n    font-weight: 600;\n}\n\n.btnBlur{\n    padding: 0.5em 1em;\n    color: gray;\n    border-radius: 30px;\n    font-weight: 600;\n}\n\n.dateTitle{\n    color: white;\n    margin: 1em 2em;\n}\n\n.subEmail{\n    color: gray;\n    font-weight: 300;\n    font-size: 0.8em;\n}\n\n.postImage{\n    margin: 1em 2em;\n    width: 25vw;\n    height: 10vw;\n}\n.postImg{\n    width: 100%;\n    height: 100%;\n    object-fit: cover;\n    border-radius: 20px;\n}\n\n.postTitle{\n    margin-left: 2em;\n    color: white;\n    font-size: 1.4em;\n}\n\n.postDesc{\n    margin:0.5em 0 0.5em 3em;\n    width: 20vw;\n    color: gray;\n}\n\n.insights{\n    align-items: center;\n    display: flex;\n    font-size: 1.3em;\n    margin-left: 2em;\n    margin-top: 1em;\n}\n\n.insightsInside{\ncolor: gray;\nalign-items: center;\ndisplay: flex;\npadding: 0 1em 0 0;\n\n}\n\n.likeIcon{\n    padding: 0 0.3em;\n    \n}\n\n.insightsInside3{\n    color: gray;\n    align-items: center;\n    display: flex;\n    margin-left:auto;\n    margin-right: 1.5em;\n    color: #4D77FF;\n    }\n\n    .addButton{\n        margin-right: 1em;\n        color: gray;\n    }\n\n.timeDiv{\n    color: gray;\n}"],"sourceRoot":""}]);
// Exports
___CSS_LOADER_EXPORT___.locals = {
	"container": "Profile_container__37VWw",
	"profile": "Profile_profile__2SlMH",
	"icons": "Profile_icons__2Kduq",
	"text": "Profile_text__3fL86",
	"image": "Profile_image__33XxL",
	"moon": "Profile_moon__20NDx",
	"message": "Profile_message__3RLCu",
	"white": "Profile_white__O2dxj",
	"dropdown": "Profile_dropdown__UOvi8",
	"title": "Profile_title__3rrrm",
	"msgImg": "Profile_msgImg__2WLZO",
	"name": "Profile_name__uA5bx",
	"sub": "Profile_sub__12g-4",
	"messageDrop": "Profile_messageDrop__3rV_7",
	"seeMore": "Profile_seeMore__3MDC7",
	"image2": "Profile_image2__1rgB6",
	"lower": "Profile_lower__3riDu",
	"image3": "Profile_image3__gf1Dq",
	"dropdown2": "Profile_dropdown2__1cK8a",
	"email": "Profile_email__1nueq",
	"button": "Profile_button__1DqQu",
	"column": "Profile_column__34t9Q",
	"row": "Profile_row__3fBSC",
	"confirm": "Profile_confirm__2ko_I",
	"column2": "Profile_column2__3S100",
	"confirm2": "Profile_confirm2__7yWXz",
	"person": "Profile_person__2ORoK",
	"searchDiv": "Profile_searchDiv__2hRbr",
	"input": "Profile_input__2j_bw",
	"searchDiv2": "Profile_searchDiv2__3vSUx",
	"input2": "Profile_input2__2PfKz",
	"titleOption": "Profile_titleOption__1ermh",
	"titleButton": "Profile_titleButton__2pI9S",
	"btnBlur": "Profile_btnBlur__1Frg6",
	"dateTitle": "Profile_dateTitle__2EiOM",
	"subEmail": "Profile_subEmail__3JdnV",
	"postImage": "Profile_postImage__1Ii8l",
	"postImg": "Profile_postImg__3DHWu",
	"postTitle": "Profile_postTitle__1seDG",
	"postDesc": "Profile_postDesc__1ns0M",
	"insights": "Profile_insights__13urD",
	"insightsInside": "Profile_insightsInside__fVGJ3",
	"likeIcon": "Profile_likeIcon__3AFwu",
	"insightsInside3": "Profile_insightsInside3__1rAzX",
	"addButton": "Profile_addButton__28HgN",
	"timeDiv": "Profile_timeDiv__1YnQl"
};
/* harmony default export */ __webpack_exports__["default"] = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/Components/Profile/StoriesHeader.module.css":
/*!************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--5-oneOf-5-1!./node_modules/postcss-loader/src??postcss!./src/Components/Profile/StoriesHeader.module.css ***!
  \************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(true);
// Module
___CSS_LOADER_EXPORT___.push([module.i, "\n.StoriesHeader_storiesContainer__3cDpI{\n    position: relative;\n    margin: 0 1em;\n}\n.StoriesHeader_white__1_QtZ{\n    color: #1F1D2B !important;\n}\n.StoriesHeader_overview__16t3w{\n    font-size: 1em;\n    font-weight: 600;\n    color: #CDCCCC;\n    font-family: 'Poppins';\n    margin: 2% 2%;\n    scroll-snap-align:start;\n}\n.StoriesHeader_stories__3tpkO{\n    display: flex;\n    flex-direction: row;\n     width: 100%;\n    overflow-x: scroll;\n    overflow-y: hidden;\n    margin-bottom: 1em;\n    flex-wrap: nowrap;\n}\n.StoriesHeader_stories__3tpkO::-webkit-scrollbar {\n\twidth: 0px;\n\theight: 0;\t\t\t   /* width of the entire scrollbar */\n  }\n.StoriesHeader_leftContainer__b6FVP{\n    width: 80%;\n    height: 100vh;\n    overflow-x: hidden;\n    overflow-y:scroll ;\n    scroll-snap-type: y mandatory;\n }\n .StoriesHeader_leftContainer__b6FVP::-webkit-scrollbar {\n\twidth: 0px;\n\theight: 0;\t\t\t   /* width of the entire scrollbar */\n  }\n .StoriesHeader_storiesLogo__E87zA{\n     width: 34px;\n     height: 34px;\n     border-radius: 70px;\n     \n    }\n   \n    .StoriesHeader_circle__IhWDe {\n        position: absolute;\n        top: 0%;\n        left: 50%;\n        width: 100%;\n        transform: translate(-50%,0%) rotate(-90deg) ;   \n        display: flex;\n        align-items: center;\n        justify-content: center;\n     \n    } \n    \n    .StoriesHeader_dialogRow__3fJSX{\n        display: flex;\n        flex-direction: row;\n        width: 65vw;\n        justify-content: space-evenly;\n    }\n    .StoriesHeader_dialog__2_m-8{\n        width: 15vw;\n        height: 10vh;\n        background-color: #16181A;\n        border-radius: 15px;\n    }\n    .StoriesHeader_svgcirclebg__1YO6_ {\n        fill: none;\n    }\n    \n    .StoriesHeader_svgcircle__1EUj1 {\n        fill: none;\n        animation: StoriesHeader_dash__28sUo 3s linear;\n    }\n    @keyframes StoriesHeader_dash__28sUo {\n        from {\n          stroke-dashoffset: 230;\n        }\n      }\n      .StoriesHeader_rowNull__1lVj6{\n          display: flex;\n          flex-direction: row;\n          width: 57vw;\n          justify-content: space-between;\n          margin-left: 2vw;\n          font-size: 21px;\n          font-weight: 600;\n          color: white;\n          font-family: 'Poppins';\n      }\n      .StoriesHeader_date__3VbGF{\n          font-size: 13px;\n          font-weight: 100;\n          color: #ABBBC2;\n      }\n    .StoriesHeader_singleRow__2CpLe{\n        display: flex;\n        flex-direction: row;\n    }\n    .StoriesHeader_horizontal__3iHDX{\n        width: 62vw;\n        border-bottom: 1px solid #393C49;\n        margin: 1% 2%;\n    }\n .StoriesHeader_storiesDiv__wvHkb{\n     margin:0 5px ;\n     padding-top: 4px;\n     position: relative;\n     align-items: center;\n     display: flex;\n     flex-direction: column;\n }\n .StoriesHeader_rightContainer__1x8Xu{\n     width: 20%;\n }\n .StoriesHeader_name__2QRsz{\n    color: white;\n    font-family: 'Poppins';\n    font-size: 0.6em;\n    margin-top: 0.5em;\n    text-transform: capitalize;\n}\n\n.StoriesHeader_absoluteDropdown__1Pa5O{\n  \n    background-color: #16181A;\n    width: 10em;\n    padding: 0 1em;\n    border-radius: 10px;\n    display: flex;\n    flex-direction: column;\n    height: max-content;\n}\n.StoriesHeader_options__2yMU2{\n    color: #FFFFFF;\n    margin: 1em 0;\n    display: flex;\n    align-items: center;\n    font-size: 0.9em;\n}\n.StoriesHeader_options2__2gI1b{\n    color: #FFFFFF;\n    margin: .8em 0;\n    display: flex;\n    align-items: center;\n    font-size: 0.7em;\n    justify-content: space-between;\n    width: 100%;\n   \n}\n.StoriesHeader_tasks__10atp{\n    color: gray;\n}\n.StoriesHeader_optional__36a6w{\n    color: #FFFFFF;\n    display: flex;\n    align-items: center;\n   }\n.StoriesHeader_food__3EaM9{\n    margin-left: 0.4em;\n}\n.StoriesHeader_foodDrop__3c4j8{\n    margin-left: 0.4em;\n}\n.StoriesHeader_absoluteDiv__3UayG{\n    position: fixed;\n    right: 0;\n    z-index: 2999;\n    width: max-content;\n    display: flex;\n}\n.StoriesHeader_absoluteDropdown2__3pulP{\n    margin: 3em 0 0 0.4em;\n    background-color: #16181A;\n    width: 15em;\n    padding: 0 1em;\n    border-radius: 10px;\n    display: none;\n    flex-direction: column;\n}\n\n.StoriesHeader_imageTop__EKFox{\n    width: 1.5em;\n    height: 1.5em;\n    border-radius: 100%;\n}\n.StoriesHeader_imageTop2__2FbWa{\n    width: 2em;\n    height: 2em;\n    border-radius: 100%;\n    \n}\n\n.StoriesHeader_topRow__3JnPb{\n    display: flex;\n    width: 100%;\n    color: #FFFFFF;\n    font-size: 0.9em;\n    align-items: center;\n    font-weight: 600;\n    margin: 1em 0;\n    justify-content: space-between;\n\n}\n", "",{"version":3,"sources":["webpack://src/Components/Profile/StoriesHeader.module.css"],"names":[],"mappings":";AACA;IACI,kBAAkB;IAClB,aAAa;AACjB;AACA;IACI,yBAAyB;AAC7B;AACA;IACI,cAAc;IACd,gBAAgB;IAChB,cAAc;IACd,sBAAsB;IACtB,aAAa;IACb,uBAAuB;AAC3B;AACA;IACI,aAAa;IACb,mBAAmB;KAClB,WAAW;IACZ,kBAAkB;IAClB,kBAAkB;IAClB,kBAAkB;IAClB,iBAAiB;AACrB;AACA;CACC,UAAU;CACV,SAAS,OAAO,kCAAkC;EACjD;AACF;IACI,UAAU;IACV,aAAa;IACb,kBAAkB;IAClB,kBAAkB;IAClB,6BAA6B;CAChC;CACA;CACA,UAAU;CACV,SAAS,OAAO,kCAAkC;EACjD;CACD;KACI,WAAW;KACX,YAAY;KACZ,mBAAmB;;IAEpB;;IAEA;QACI,kBAAkB;QAClB,OAAO;QACP,SAAS;QACT,WAAW;QACX,6CAA6C;QAC7C,aAAa;QACb,mBAAmB;QACnB,uBAAuB;;IAE3B;;IAEA;QACI,aAAa;QACb,mBAAmB;QACnB,WAAW;QACX,6BAA6B;IACjC;IACA;QACI,WAAW;QACX,YAAY;QACZ,yBAAyB;QACzB,mBAAmB;IACvB;IACA;QACI,UAAU;IACd;;IAEA;QACI,UAAU;QACV,8CAAyB;IAC7B;IACA;QACI;UACE,sBAAsB;QACxB;MACF;MACA;UACI,aAAa;UACb,mBAAmB;UACnB,WAAW;UACX,8BAA8B;UAC9B,gBAAgB;UAChB,eAAe;UACf,gBAAgB;UAChB,YAAY;UACZ,sBAAsB;MAC1B;MACA;UACI,eAAe;UACf,gBAAgB;UAChB,cAAc;MAClB;IACF;QACI,aAAa;QACb,mBAAmB;IACvB;IACA;QACI,WAAW;QACX,gCAAgC;QAChC,aAAa;IACjB;CACH;KACI,aAAa;KACb,gBAAgB;KAChB,kBAAkB;KAClB,mBAAmB;KACnB,aAAa;KACb,sBAAsB;CAC1B;CACA;KACI,UAAU;CACd;CACA;IACG,YAAY;IACZ,sBAAsB;IACtB,gBAAgB;IAChB,iBAAiB;IACjB,0BAA0B;AAC9B;;AAEA;;IAEI,yBAAyB;IACzB,WAAW;IACX,cAAc;IACd,mBAAmB;IACnB,aAAa;IACb,sBAAsB;IACtB,mBAAmB;AACvB;AACA;IACI,cAAc;IACd,aAAa;IACb,aAAa;IACb,mBAAmB;IACnB,gBAAgB;AACpB;AACA;IACI,cAAc;IACd,cAAc;IACd,aAAa;IACb,mBAAmB;IACnB,gBAAgB;IAChB,8BAA8B;IAC9B,WAAW;;AAEf;AACA;IACI,WAAW;AACf;AACA;IACI,cAAc;IACd,aAAa;IACb,mBAAmB;GACpB;AACH;IACI,kBAAkB;AACtB;AACA;IACI,kBAAkB;AACtB;AACA;IACI,eAAe;IACf,QAAQ;IACR,aAAa;IACb,kBAAkB;IAClB,aAAa;AACjB;AACA;IACI,qBAAqB;IACrB,yBAAyB;IACzB,WAAW;IACX,cAAc;IACd,mBAAmB;IACnB,aAAa;IACb,sBAAsB;AAC1B;;AAEA;IACI,YAAY;IACZ,aAAa;IACb,mBAAmB;AACvB;AACA;IACI,UAAU;IACV,WAAW;IACX,mBAAmB;;AAEvB;;AAEA;IACI,aAAa;IACb,WAAW;IACX,cAAc;IACd,gBAAgB;IAChB,mBAAmB;IACnB,gBAAgB;IAChB,aAAa;IACb,8BAA8B;;AAElC","sourcesContent":["\n.storiesContainer{\n    position: relative;\n    margin: 0 1em;\n}\n.white{\n    color: #1F1D2B !important;\n}\n.overview{\n    font-size: 1em;\n    font-weight: 600;\n    color: #CDCCCC;\n    font-family: 'Poppins';\n    margin: 2% 2%;\n    scroll-snap-align:start;\n}\n.stories{\n    display: flex;\n    flex-direction: row;\n     width: 100%;\n    overflow-x: scroll;\n    overflow-y: hidden;\n    margin-bottom: 1em;\n    flex-wrap: nowrap;\n}\n.stories::-webkit-scrollbar {\n\twidth: 0px;\n\theight: 0;\t\t\t   /* width of the entire scrollbar */\n  }\n.leftContainer{\n    width: 80%;\n    height: 100vh;\n    overflow-x: hidden;\n    overflow-y:scroll ;\n    scroll-snap-type: y mandatory;\n }\n .leftContainer::-webkit-scrollbar {\n\twidth: 0px;\n\theight: 0;\t\t\t   /* width of the entire scrollbar */\n  }\n .storiesLogo{\n     width: 34px;\n     height: 34px;\n     border-radius: 70px;\n     \n    }\n   \n    .circle {\n        position: absolute;\n        top: 0%;\n        left: 50%;\n        width: 100%;\n        transform: translate(-50%,0%) rotate(-90deg) ;   \n        display: flex;\n        align-items: center;\n        justify-content: center;\n     \n    } \n    \n    .dialogRow{\n        display: flex;\n        flex-direction: row;\n        width: 65vw;\n        justify-content: space-evenly;\n    }\n    .dialog{\n        width: 15vw;\n        height: 10vh;\n        background-color: #16181A;\n        border-radius: 15px;\n    }\n    .svgcirclebg {\n        fill: none;\n    }\n    \n    .svgcircle {\n        fill: none;\n        animation: dash 3s linear;\n    }\n    @keyframes dash {\n        from {\n          stroke-dashoffset: 230;\n        }\n      }\n      .rowNull{\n          display: flex;\n          flex-direction: row;\n          width: 57vw;\n          justify-content: space-between;\n          margin-left: 2vw;\n          font-size: 21px;\n          font-weight: 600;\n          color: white;\n          font-family: 'Poppins';\n      }\n      .date{\n          font-size: 13px;\n          font-weight: 100;\n          color: #ABBBC2;\n      }\n    .singleRow{\n        display: flex;\n        flex-direction: row;\n    }\n    .horizontal{\n        width: 62vw;\n        border-bottom: 1px solid #393C49;\n        margin: 1% 2%;\n    }\n .storiesDiv{\n     margin:0 5px ;\n     padding-top: 4px;\n     position: relative;\n     align-items: center;\n     display: flex;\n     flex-direction: column;\n }\n .rightContainer{\n     width: 20%;\n }\n .name{\n    color: white;\n    font-family: 'Poppins';\n    font-size: 0.6em;\n    margin-top: 0.5em;\n    text-transform: capitalize;\n}\n\n.absoluteDropdown{\n  \n    background-color: #16181A;\n    width: 10em;\n    padding: 0 1em;\n    border-radius: 10px;\n    display: flex;\n    flex-direction: column;\n    height: max-content;\n}\n.options{\n    color: #FFFFFF;\n    margin: 1em 0;\n    display: flex;\n    align-items: center;\n    font-size: 0.9em;\n}\n.options2{\n    color: #FFFFFF;\n    margin: .8em 0;\n    display: flex;\n    align-items: center;\n    font-size: 0.7em;\n    justify-content: space-between;\n    width: 100%;\n   \n}\n.tasks{\n    color: gray;\n}\n.optional{\n    color: #FFFFFF;\n    display: flex;\n    align-items: center;\n   }\n.food{\n    margin-left: 0.4em;\n}\n.foodDrop{\n    margin-left: 0.4em;\n}\n.absoluteDiv{\n    position: fixed;\n    right: 0;\n    z-index: 2999;\n    width: max-content;\n    display: flex;\n}\n.absoluteDropdown2{\n    margin: 3em 0 0 0.4em;\n    background-color: #16181A;\n    width: 15em;\n    padding: 0 1em;\n    border-radius: 10px;\n    display: none;\n    flex-direction: column;\n}\n\n.imageTop{\n    width: 1.5em;\n    height: 1.5em;\n    border-radius: 100%;\n}\n.imageTop2{\n    width: 2em;\n    height: 2em;\n    border-radius: 100%;\n    \n}\n\n.topRow{\n    display: flex;\n    width: 100%;\n    color: #FFFFFF;\n    font-size: 0.9em;\n    align-items: center;\n    font-weight: 600;\n    margin: 1em 0;\n    justify-content: space-between;\n\n}\n"],"sourceRoot":""}]);
// Exports
___CSS_LOADER_EXPORT___.locals = {
	"storiesContainer": "StoriesHeader_storiesContainer__3cDpI",
	"white": "StoriesHeader_white__1_QtZ",
	"overview": "StoriesHeader_overview__16t3w",
	"stories": "StoriesHeader_stories__3tpkO",
	"leftContainer": "StoriesHeader_leftContainer__b6FVP",
	"storiesLogo": "StoriesHeader_storiesLogo__E87zA",
	"circle": "StoriesHeader_circle__IhWDe",
	"dialogRow": "StoriesHeader_dialogRow__3fJSX",
	"dialog": "StoriesHeader_dialog__2_m-8",
	"svgcirclebg": "StoriesHeader_svgcirclebg__1YO6_",
	"svgcircle": "StoriesHeader_svgcircle__1EUj1",
	"dash": "StoriesHeader_dash__28sUo",
	"rowNull": "StoriesHeader_rowNull__1lVj6",
	"date": "StoriesHeader_date__3VbGF",
	"singleRow": "StoriesHeader_singleRow__2CpLe",
	"horizontal": "StoriesHeader_horizontal__3iHDX",
	"storiesDiv": "StoriesHeader_storiesDiv__wvHkb",
	"rightContainer": "StoriesHeader_rightContainer__1x8Xu",
	"name": "StoriesHeader_name__2QRsz",
	"absoluteDropdown": "StoriesHeader_absoluteDropdown__1Pa5O",
	"options": "StoriesHeader_options__2yMU2",
	"options2": "StoriesHeader_options2__2gI1b",
	"tasks": "StoriesHeader_tasks__10atp",
	"optional": "StoriesHeader_optional__36a6w",
	"food": "StoriesHeader_food__3EaM9",
	"foodDrop": "StoriesHeader_foodDrop__3c4j8",
	"absoluteDiv": "StoriesHeader_absoluteDiv__3UayG",
	"absoluteDropdown2": "StoriesHeader_absoluteDropdown2__3pulP",
	"imageTop": "StoriesHeader_imageTop__EKFox",
	"imageTop2": "StoriesHeader_imageTop2__2FbWa",
	"topRow": "StoriesHeader_topRow__3JnPb"
};
/* harmony default export */ __webpack_exports__["default"] = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./src/Components/Profile/Header.jsx":
/*!*******************************************!*\
  !*** ./src/Components/Profile/Header.jsx ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(__react_refresh_utils__, __react_refresh_error_overlay__) {/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _StoriesHeader_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./StoriesHeader.module.css */ "./src/Components/Profile/StoriesHeader.module.css");
/* harmony import */ var _StoriesHeader_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_StoriesHeader_module_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Home_demo_png__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Home/demo.png */ "./src/Components/Home/demo.png");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! classnames */ "./node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-icons/ai */ "./node_modules/react-icons/ai/index.esm.js");
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-icons/hi */ "./node_modules/react-icons/hi/index.esm.js");
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-icons/io5 */ "./node_modules/react-icons/io5/index.esm.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__);
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");
__webpack_require__.$Refresh$.setup(module.i);

var _jsxFileName = "/Users/blacktech/Documents/restrox-reception/src/Components/Profile/Header.jsx",
    _s = __webpack_require__.$Refresh$.signature();










const Header = props => {
  _s();

  const [stories, setStories] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])([{
    'Name': 'Add Expense',
    'image': '/demo.png',
    'value': '44'
  }, {
    'Name': 'Add Order',
    'image': '/demo.png',
    'value': '44'
  }, {
    'Name': 'Add Notes',
    'image': '/demo.png',
    'value': '44'
  }]);
  const [show, setShow] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false);
  const size = "40px";
  const center = "20px";
  const radius = "16.5";
  const strokeWidth = "3px";
  const circleOneStroke = props.theme ? "rgba(31, 29, 42, 0.084)" : "gray";
  const circleTwoStroke = 'tomato';
  const wrapperRef = Object(react__WEBPACK_IMPORTED_MODULE_0__["useRef"])(null);
  const [coordinates, setCoordinates] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])({
    x: '',
    y: ''
  });

  const showDiv = add => {
    const a = document.getElementById('sideDrop');

    if (add) {
      a.style.display = "none";
    } else {
      a.style.display = "flex";
    }
  };

  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    /**
     * Alert if clicked on outside of element
     */
    function handleClickOutside(event) {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target)) {
        setShow(false);
      }
    } // Bind the event listener


    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      // Unbind the event listener on clean up
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [wrapperRef]);

  const clickHandler = event => {
    setCoordinates({
      x: event.pageX,
      y: event.pageY
    });
    setShow(true);
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])("div", {
    className: _StoriesHeader_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.storiesContainer,
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])("div", {
      className: _StoriesHeader_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.stories,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])("div", {
        className: _StoriesHeader_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.singleRow,
        children: stories.slice(0, 3).map(dat => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])("div", {
          className: _StoriesHeader_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.storiesDiv,
          onClick: () => {
            props.modalHandle(dat.Name);
          },
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])("img", {
            className: _StoriesHeader_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.storiesLogo,
            src: _Home_demo_png__WEBPACK_IMPORTED_MODULE_2__["default"]
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 61,
            columnNumber: 21
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])("div", {
            className: _StoriesHeader_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.circle,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])("svg", {
              className: _StoriesHeader_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.svg,
              width: size,
              height: size,
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])("circle", {
                className: _StoriesHeader_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.svgcirclebg,
                stroke: circleOneStroke,
                cx: center,
                cy: center,
                r: radius,
                strokeWidth: strokeWidth
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 64,
                columnNumber: 25
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])("circle", {
                className: _StoriesHeader_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.svgcircle,
                stroke: circleTwoStroke,
                cx: center,
                cy: center,
                r: radius,
                strokeWidth: strokeWidth,
                strokeDasharray: 2 * Math.PI * parseInt(radius),
                strokeDashoffset: (100 - parseInt(dat.value)) / 100 * 2 * Math.PI * parseInt(radius)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 72,
                columnNumber: 25
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 63,
              columnNumber: 21
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 62,
            columnNumber: 21
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])("div", {
            className: classnames__WEBPACK_IMPORTED_MODULE_3___default()(_StoriesHeader_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.name, props.theme ? _StoriesHeader_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.white : null),
            children: dat.Name
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 85,
            columnNumber: 25
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 60,
          columnNumber: 48
        }, undefined))
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 59,
        columnNumber: 17
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 58,
      columnNumber: 13
    }, undefined), show ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])("div", {
      className: _StoriesHeader_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.absoluteDiv,
      ref: wrapperRef,
      style: {
        top: `${coordinates.y}px`,
        left: `${coordinates.x}px`
      },
      onMouseLeave: () => showDiv("hide"),
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])("div", {
        className: _StoriesHeader_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.absoluteDropdown,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])("div", {
          className: _StoriesHeader_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.options,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])(react_icons_ai__WEBPACK_IMPORTED_MODULE_4__["AiFillEye"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 95,
            columnNumber: 28
          }, undefined), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])("div", {
            className: _StoriesHeader_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.food,
            children: "View"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 95,
            columnNumber: 41
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 94,
          columnNumber: 25
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])("div", {
          className: _StoriesHeader_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.options,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])(react_icons_ai__WEBPACK_IMPORTED_MODULE_4__["AiOutlineUsergroupAdd"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 98,
            columnNumber: 28
          }, undefined), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])("div", {
            className: _StoriesHeader_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.foodDrop,
            onMouseEnter: () => showDiv(),
            children: "Assign to Staff"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 98,
            columnNumber: 53
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 97,
          columnNumber: 25
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])("div", {
          className: _StoriesHeader_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.options,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])(react_icons_io5__WEBPACK_IMPORTED_MODULE_6__["IoCheckmarkDone"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 101,
            columnNumber: 28
          }, undefined), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])("div", {
            className: _StoriesHeader_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.food,
            children: "Mark as Done"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 101,
            columnNumber: 47
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 100,
          columnNumber: 25
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 92,
        columnNumber: 13
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])("div", {
        className: _StoriesHeader_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.absoluteDropdown2,
        id: "sideDrop",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])("div", {
          className: _StoriesHeader_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.topRow,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])("div", {
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])(react_icons_hi__WEBPACK_IMPORTED_MODULE_5__["HiUserAdd"], {
              style: {
                marginRight: "0.4em"
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 108,
              columnNumber: 28
            }, undefined), "Assign Task to"]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 107,
            columnNumber: 28
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])("img", {
            className: _StoriesHeader_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.imageTop,
            src: "/images/user.jpeg"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 111,
            columnNumber: 28
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 105,
          columnNumber: 24
        }, undefined), stories.map(dat => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])("div", {
          className: _StoriesHeader_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.options2,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])("div", {
            className: _StoriesHeader_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.optional,
            children: ["  ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])("img", {
              className: _StoriesHeader_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.imageTop2,
              src: "/images/user.jpeg"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 115,
              columnNumber: 62
            }, undefined), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])("div", {
              className: _StoriesHeader_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.food,
              children: "Anis Acharya"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 115,
              columnNumber: 122
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 115,
            columnNumber: 27
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])("div", {
            className: _StoriesHeader_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.tasks,
            children: "24 Task remaining"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 116,
            columnNumber: 27
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 114,
          columnNumber: 29
        }, undefined))]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 104,
        columnNumber: 13
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 91,
      columnNumber: 19
    }, undefined) : null]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 57,
    columnNumber: 9
  }, undefined);
};

_s(Header, "24U0euAk32aITrFBXoQQp3OOpxM=");

_c = Header;
/* harmony default export */ __webpack_exports__["default"] = (Header);

var _c;

__webpack_require__.$Refresh$.register(_c, "Header");

const currentExports = __react_refresh_utils__.getModuleExports(module.i);
__react_refresh_utils__.registerExportsForReactRefresh(currentExports, module.i);

if (true) {
  const isHotUpdate = !!module.hot.data;
  const prevExports = isHotUpdate ? module.hot.data.prevExports : null;

  if (__react_refresh_utils__.isReactRefreshBoundary(currentExports)) {
    module.hot.dispose(
      /**
       * A callback to performs a full refresh if React has unrecoverable errors,
       * and also caches the to-be-disposed module.
       * @param {*} data A hot module data object from Webpack HMR.
       * @returns {void}
       */
      function hotDisposeCallback(data) {
        // We have to mutate the data object to get data registered and cached
        data.prevExports = currentExports;
      }
    );
    module.hot.accept(
      /**
       * An error handler to allow self-recovering behaviours.
       * @param {Error} error An error occurred during evaluation of a module.
       * @returns {void}
       */
      function hotErrorHandler(error) {
        if (
          typeof __react_refresh_error_overlay__ !== 'undefined' &&
          __react_refresh_error_overlay__
        ) {
          __react_refresh_error_overlay__.handleRuntimeError(error);
        }

        if (typeof __react_refresh_test__ !== 'undefined' && __react_refresh_test__) {
          if (window.onHotAcceptError) {
            window.onHotAcceptError(error.message);
          }
        }

        __webpack_require__.c[module.i].hot.accept(hotErrorHandler);
      }
    );

    if (isHotUpdate) {
      if (
        __react_refresh_utils__.isReactRefreshBoundary(prevExports) &&
        __react_refresh_utils__.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)
      ) {
        module.hot.invalidate();
      } else {
        __react_refresh_utils__.enqueueUpdate(
          /**
           * A function to dismiss the error overlay after performing React refresh.
           * @returns {void}
           */
          function updateCallback() {
            if (
              typeof __react_refresh_error_overlay__ !== 'undefined' &&
              __react_refresh_error_overlay__
            ) {
              __react_refresh_error_overlay__.clearRuntimeErrors();
            }
          }
        );
      }
    }
  } else {
    if (isHotUpdate && __react_refresh_utils__.isReactRefreshBoundary(prevExports)) {
      module.hot.invalidate();
    }
  }
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js"), __webpack_require__(/*! ./node_modules/react-dev-utils/refreshOverlayInterop.js */ "./node_modules/react-dev-utils/refreshOverlayInterop.js")))

/***/ }),

/***/ "./src/Components/Profile/Profile.jsx":
/*!********************************************!*\
  !*** ./src/Components/Profile/Profile.jsx ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(__react_refresh_utils__, __react_refresh_error_overlay__) {/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Profile_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Profile.module.css */ "./src/Components/Profile/Profile.module.css");
/* harmony import */ var _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_Profile_module_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-icons/bi */ "./node_modules/react-icons/bi/index.esm.js");
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-icons/io */ "./node_modules/react-icons/io/index.esm.js");
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-icons/io5 */ "./node_modules/react-icons/io5/index.esm.js");
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-icons/ri */ "./node_modules/react-icons/ri/index.esm.js");
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! .. */ "./src/Components/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! classnames */ "./node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-icons/ai */ "./node_modules/react-icons/ai/index.esm.js");
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../api */ "./src/api/index.js");
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react-icons/fa */ "./node_modules/react-icons/fa/index.esm.js");
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! react-icons/bs */ "./node_modules/react-icons/bs/index.esm.js");
/* harmony import */ var _StoriesHeader_StoriesHeader__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../StoriesHeader/StoriesHeader */ "./src/Components/StoriesHeader/StoriesHeader.jsx");
/* harmony import */ var _Header_jsx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./Header.jsx */ "./src/Components/Profile/Header.jsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__);
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");
__webpack_require__.$Refresh$.setup(module.i);

var _jsxFileName = "/Users/blacktech/Documents/restrox-reception/src/Components/Profile/Profile.jsx",
    _s = __webpack_require__.$Refresh$.signature();




















const Profile = props => {
  _s();

  const [view, setView] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])({
    message: false,
    notification: false,
    settings: false
  });
  const [data, setData] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])();
  const [logout, setLogout] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false);
  const wrapperRef = Object(react__WEBPACK_IMPORTED_MODULE_0__["useRef"])(null);
  const [status, setStatus] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])('Activity');
  const [showHeader, setShowHeader] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false);
  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    /**
     * Alert if clicked on outside of element
     */
    function handleClickOutside(event) {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target)) {
        setView(false);
      }
    } // Bind the event listener


    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      // Unbind the event listener on clean up
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [wrapperRef]);
  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    const fetchData = async () => {
      setData(await Object(_api__WEBPACK_IMPORTED_MODULE_9__["Bills"])());
    };

    fetchData();
  }, []);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
    className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.container,
    ref: wrapperRef,
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
      className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.profile,
      children: [showHeader ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
        className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.headerDiv,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(_Header_jsx__WEBPACK_IMPORTED_MODULE_13__["default"], { ...props
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 61,
          columnNumber: 22
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 60,
        columnNumber: 22
      }, undefined) : null, /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(react_icons_io5__WEBPACK_IMPORTED_MODULE_4__["IoAddCircleOutline"], {
          size: "2em",
          className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.addButton,
          onClick: () => setShowHeader(prev => !prev)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 65,
          columnNumber: 18
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 64,
        columnNumber: 18
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
        className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.searchDiv,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("input", {
          className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.input,
          placeholder: "Search here"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 68,
          columnNumber: 17
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(react_icons_ai__WEBPACK_IMPORTED_MODULE_8__["AiOutlineSearch"], {
          size: "1.5em",
          color: "gray"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 69,
          columnNumber: 17
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 67,
        columnNumber: 13
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("img", {
          src: "/images/moon.png",
          className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.moon
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 72,
          columnNumber: 13
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 71,
        columnNumber: 13
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(react_icons_bi__WEBPACK_IMPORTED_MODULE_2__["BiMessageSquareDots"], {
        size: "1.5em",
        color: "gray",
        className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.icons,
        onClick: () => setView({
          message: true
        })
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 74,
        columnNumber: 13
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(react_icons_io__WEBPACK_IMPORTED_MODULE_3__["IoIosNotificationsOutline"], {
        size: "1.5em",
        color: "gray",
        className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.icons,
        onClick: () => setView({
          notification: true
        })
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 75,
        columnNumber: 13
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("img", {
        src: 'https://www.niemanlab.org/images/Greg-Emerson-edit-2.jpg',
        className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.image
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 76,
        columnNumber: 13
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_7___default()(_Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.text, props.theme ? _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.white : null),
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
          className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.person,
          children: "Samir Ck"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 78,
          columnNumber: 16
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
          children: "Receptionist"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 81,
          columnNumber: 17
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 77,
        columnNumber: 13
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(react_icons_ri__WEBPACK_IMPORTED_MODULE_5__["RiArrowDropDownLine"], {
        size: "2em",
        color: "gray",
        className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.icons,
        onClick: () => setView({
          settings: true
        })
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 86,
        columnNumber: 12
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 58,
      columnNumber: 14
    }, undefined), view.message ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
      className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.dropdown,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
        className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.messageDrop,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
          className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.title,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
            children: " Chats "
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 93,
            columnNumber: 24
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
            children: [" ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(react_icons_fa__WEBPACK_IMPORTED_MODULE_10__["FaRegEdit"], {}, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 94,
              columnNumber: 30
            }, undefined), " "]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 94,
            columnNumber: 24
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 92,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
          className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.searchDiv2,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(react_icons_ai__WEBPACK_IMPORTED_MODULE_8__["AiOutlineSearch"], {
            size: "1.5em",
            color: "gray"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 97,
            columnNumber: 24
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("input", {
            className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.input2,
            placeholder: "Search messages"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 98,
            columnNumber: 25
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 96,
          columnNumber: 21
        }, undefined), [1, 2, 3, 4, 5].map(dat => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
          className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.message,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("img", {
              className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.msgImg,
              src: "/images/user.jpeg"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 103,
              columnNumber: 29
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 102,
            columnNumber: 25
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
            className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.name,
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
              children: "Subin Bhandari"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 106,
              columnNumber: 29
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
              className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.sub,
              children: "Hello, Kcha hajurrrr"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 109,
              columnNumber: 29
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 105,
            columnNumber: 25
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
            className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.timeDiv,
            children: [new Date().getHours(), ":", new Date().getMinutes()]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 113,
            columnNumber: 25
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 101,
          columnNumber: 45
        }, undefined))]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 91,
        columnNumber: 16
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
        className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.seeMore,
        children: "See More"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 119,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 90,
      columnNumber: 23
    }, undefined) : null, view.notification ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
      className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.dropdown,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
        className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.titleOption,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
          className: status == 'Activity' ? _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.titleButton : _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.btnBlur,
          onClick: () => setStatus('Activity'),
          children: "Activity"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 125,
          columnNumber: 23
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
          className: status != 'Activity' ? _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.titleButton : _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.btnBlur,
          onClick: () => setStatus('asdsad'),
          children: "Updates"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 128,
          columnNumber: 22
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 124,
        columnNumber: 12
      }, undefined), status == 'Activity' ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
        className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.messageDrop,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
          className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.dateTitle,
          children: "Today's"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 134,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
          className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.message,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("img", {
              className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.msgImg,
              src: "/images/user.jpeg"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 139,
              columnNumber: 29
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 138,
            columnNumber: 25
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
            className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.name,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
              children: "Subin Bhandari and 4 others recently reviewed your food"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 142,
              columnNumber: 29
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 141,
            columnNumber: 25
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 137,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 132,
        columnNumber: 36
      }, undefined) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
        className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.messageDrop,
        children: Object.keys(data.arra).map((dat, index) => data.arra[dat].map((itm, itmIndex) => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
          className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.postDivision,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
            className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.message,
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("img", {
                className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.msgImg,
                src: itm.owner.picture
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 158,
                columnNumber: 24
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 157,
              columnNumber: 20
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
              className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.name,
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                children: [itm.owner.firstName, " ", itm.owner.lastName]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 161,
                columnNumber: 24
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.subEmail,
                children: itm.owner.email
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 164,
                columnNumber: 23
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 160,
              columnNumber: 20
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 156,
            columnNumber: 19
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
            className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.postImage,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("img", {
              className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.postImg,
              src: itm.image
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 170,
              columnNumber: 21
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 169,
            columnNumber: 21
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
            className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.postTitle,
            children: itm.id
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 172,
            columnNumber: 21
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
            className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.postDesc,
            children: itm.text
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 175,
            columnNumber: 21
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
            className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.insights,
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
              className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.insightsInside,
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(react_icons_ai__WEBPACK_IMPORTED_MODULE_8__["AiOutlineHeart"], {
                size: "1.3em",
                className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.likeIcon
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 180,
                columnNumber: 25
              }, undefined), " ", itm.likes * 15]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 179,
              columnNumber: 21
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
              className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.insightsInside,
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(react_icons_fa__WEBPACK_IMPORTED_MODULE_10__["FaRegComment"], {
                size: "1.3em",
                className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.likeIcon
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 183,
                columnNumber: 25
              }, undefined), " ", itm.likes * 2]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 182,
              columnNumber: 21
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
              className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.insightsInside3,
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(react_icons_bs__WEBPACK_IMPORTED_MODULE_11__["BsFillBookmarkFill"], {
                size: "1.3em",
                className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.likeIcon
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 186,
                columnNumber: 25
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 185,
              columnNumber: 21
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 178,
            columnNumber: 21
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 155,
          columnNumber: 16
        }, undefined)))
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 150,
        columnNumber: 16
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
        className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.seeMore,
        children: "See More"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 196,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 123,
      columnNumber: 32
    }, undefined) : null, view.settings ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
      className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.dropdown2,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
        className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.image2,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("img", {
          src: "/images/pana.png",
          width: "70%"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 203,
          columnNumber: 17
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 201,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
        className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.lower,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("img", {
            src: "/images/user.jpeg",
            className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.image3
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 207,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 206,
          columnNumber: 16
        }, undefined), logout ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
          className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.row,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
            className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.confirm,
            children: "Are you sure you want to sign out from your account now?"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 213,
            columnNumber: 29
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
            className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.confirm2,
            children: "If you dont press any button you will be logged out automatically in 40 seconds"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 216,
            columnNumber: 29
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
            className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.column2,
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
              className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.button,
              onClick: () => setLogout(false),
              children: "Cancel"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 220,
              columnNumber: 25
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
              className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.button,
              children: "Sign out"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 223,
              columnNumber: 25
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 219,
            columnNumber: 29
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 211,
          columnNumber: 28
        }, undefined) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
          style: {
            width: "100%",
            display: "flex",
            flexDirection: "column",
            alignItems: "center"
          },
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
            children: "Samir Ck"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 229,
            columnNumber: 23
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
            className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.email,
            children: "samir@restor-x.com"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 232,
            columnNumber: 19
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
            className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.column,
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
              className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.button,
              children: "Profile"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 236,
              columnNumber: 25
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
              className: _Profile_module_css__WEBPACK_IMPORTED_MODULE_1___default.a.button,
              onClick: () => setLogout(true),
              children: "Sign out"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 239,
              columnNumber: 25
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 235,
            columnNumber: 21
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 228,
          columnNumber: 23
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 205,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 200,
      columnNumber: 28
    }, undefined) : null]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 57,
    columnNumber: 9
  }, undefined);
};

_s(Profile, "GWBfNGEL4NVWQifbv2dv/zKnwMs=");

_c = Profile;
/* harmony default export */ __webpack_exports__["default"] = (Profile);

var _c;

__webpack_require__.$Refresh$.register(_c, "Profile");

const currentExports = __react_refresh_utils__.getModuleExports(module.i);
__react_refresh_utils__.registerExportsForReactRefresh(currentExports, module.i);

if (true) {
  const isHotUpdate = !!module.hot.data;
  const prevExports = isHotUpdate ? module.hot.data.prevExports : null;

  if (__react_refresh_utils__.isReactRefreshBoundary(currentExports)) {
    module.hot.dispose(
      /**
       * A callback to performs a full refresh if React has unrecoverable errors,
       * and also caches the to-be-disposed module.
       * @param {*} data A hot module data object from Webpack HMR.
       * @returns {void}
       */
      function hotDisposeCallback(data) {
        // We have to mutate the data object to get data registered and cached
        data.prevExports = currentExports;
      }
    );
    module.hot.accept(
      /**
       * An error handler to allow self-recovering behaviours.
       * @param {Error} error An error occurred during evaluation of a module.
       * @returns {void}
       */
      function hotErrorHandler(error) {
        if (
          typeof __react_refresh_error_overlay__ !== 'undefined' &&
          __react_refresh_error_overlay__
        ) {
          __react_refresh_error_overlay__.handleRuntimeError(error);
        }

        if (typeof __react_refresh_test__ !== 'undefined' && __react_refresh_test__) {
          if (window.onHotAcceptError) {
            window.onHotAcceptError(error.message);
          }
        }

        __webpack_require__.c[module.i].hot.accept(hotErrorHandler);
      }
    );

    if (isHotUpdate) {
      if (
        __react_refresh_utils__.isReactRefreshBoundary(prevExports) &&
        __react_refresh_utils__.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)
      ) {
        module.hot.invalidate();
      } else {
        __react_refresh_utils__.enqueueUpdate(
          /**
           * A function to dismiss the error overlay after performing React refresh.
           * @returns {void}
           */
          function updateCallback() {
            if (
              typeof __react_refresh_error_overlay__ !== 'undefined' &&
              __react_refresh_error_overlay__
            ) {
              __react_refresh_error_overlay__.clearRuntimeErrors();
            }
          }
        );
      }
    }
  } else {
    if (isHotUpdate && __react_refresh_utils__.isReactRefreshBoundary(prevExports)) {
      module.hot.invalidate();
    }
  }
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js"), __webpack_require__(/*! ./node_modules/react-dev-utils/refreshOverlayInterop.js */ "./node_modules/react-dev-utils/refreshOverlayInterop.js")))

/***/ }),

/***/ "./src/Components/Profile/Profile.module.css":
/*!***************************************************!*\
  !*** ./src/Components/Profile/Profile.module.css ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--5-oneOf-5-1!../../../node_modules/postcss-loader/src??postcss!./Profile.module.css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/Components/Profile/Profile.module.css");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);


if (true) {
  if (!content.locals || module.hot.invalidate) {
    var isEqualLocals = function isEqualLocals(a, b, isNamedExport) {
  if (!a && b || a && !b) {
    return false;
  }

  var p;

  for (p in a) {
    if (isNamedExport && p === 'default') {
      // eslint-disable-next-line no-continue
      continue;
    }

    if (a[p] !== b[p]) {
      return false;
    }
  }

  for (p in b) {
    if (isNamedExport && p === 'default') {
      // eslint-disable-next-line no-continue
      continue;
    }

    if (!a[p]) {
      return false;
    }
  }

  return true;
};
    var oldLocals = content.locals;

    module.hot.accept(
      /*! !../../../node_modules/css-loader/dist/cjs.js??ref--5-oneOf-5-1!../../../node_modules/postcss-loader/src??postcss!./Profile.module.css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/Components/Profile/Profile.module.css",
      function () {
        content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--5-oneOf-5-1!../../../node_modules/postcss-loader/src??postcss!./Profile.module.css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/Components/Profile/Profile.module.css");

              content = content.__esModule ? content.default : content;

              if (typeof content === 'string') {
                content = [[module.i, content, '']];
              }

              if (!isEqualLocals(oldLocals, content.locals)) {
                module.hot.invalidate();

                return;
              }

              oldLocals = content.locals;

              update(content);
      }
    )
  }

  module.hot.dispose(function() {
    update();
  });
}

module.exports = content.locals || {};

/***/ }),

/***/ "./src/Components/Profile/StoriesHeader.module.css":
/*!*********************************************************!*\
  !*** ./src/Components/Profile/StoriesHeader.module.css ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--5-oneOf-5-1!../../../node_modules/postcss-loader/src??postcss!./StoriesHeader.module.css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/Components/Profile/StoriesHeader.module.css");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);


if (true) {
  if (!content.locals || module.hot.invalidate) {
    var isEqualLocals = function isEqualLocals(a, b, isNamedExport) {
  if (!a && b || a && !b) {
    return false;
  }

  var p;

  for (p in a) {
    if (isNamedExport && p === 'default') {
      // eslint-disable-next-line no-continue
      continue;
    }

    if (a[p] !== b[p]) {
      return false;
    }
  }

  for (p in b) {
    if (isNamedExport && p === 'default') {
      // eslint-disable-next-line no-continue
      continue;
    }

    if (!a[p]) {
      return false;
    }
  }

  return true;
};
    var oldLocals = content.locals;

    module.hot.accept(
      /*! !../../../node_modules/css-loader/dist/cjs.js??ref--5-oneOf-5-1!../../../node_modules/postcss-loader/src??postcss!./StoriesHeader.module.css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/Components/Profile/StoriesHeader.module.css",
      function () {
        content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--5-oneOf-5-1!../../../node_modules/postcss-loader/src??postcss!./StoriesHeader.module.css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/Components/Profile/StoriesHeader.module.css");

              content = content.__esModule ? content.default : content;

              if (typeof content === 'string') {
                content = [[module.i, content, '']];
              }

              if (!isEqualLocals(oldLocals, content.locals)) {
                module.hot.invalidate();

                return;
              }

              oldLocals = content.locals;

              update(content);
      }
    )
  }

  module.hot.dispose(function() {
    update();
  });
}

module.exports = content.locals || {};

/***/ })

}]);
//# sourceMappingURL=5.chunk.js.map